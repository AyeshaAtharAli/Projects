#include<iostream>
#include<cstdlib>
#include<ctime>
#include<iomanip>
using namespace std;

int randomNumber()
{
	srand(time(NULL));
	int Randnum;
	for(int i=0; i<10000; i++){
		Randnum = rand() % 3;
		if (Randnum != 0){
			break;
		}
	}
	return Randnum;
}

void randomIndex(int board[4][4] , int &num1 , int &num2)
{
	srand(time(NULL));
	//Number b/w 0 and 5
	for(int i=0; i<10000; i++){
	num1 = rand() % 4;
	num2 = rand() % 4;
	if(board[num1][num2] == 0){
		break;
	}
	}
}

void mainGrid(int board[4][4]){
	
	cout<<endl<<endl;
	cout<<setw(70)<<"ENTER Q TO QUIT THE GAME "<<endl;
	cout<<setw(65)<<"ENTER L TO MOVE LEFT"<<endl;
	cout<<setw(67)<<"ENTER R TO MOVE RIGHT "<<endl;
	cout<<setw(68)<<"ENTER U TO MOVE UPWARD "<<endl;
	cout<<setw(70)<<"ENTER D TO MOVE DOWNWARD "<<endl;
	cout<<endl<<endl;
	
	for(int i=0; i<4; i++){
		cout<<setw(98)<<"------------------------------------------------------------------------------------------"<<endl;
	for (int j=0; j<4; j++){
		cout<<"        |";
		cout<<"        ";
		if (board[i][j] == 0)
		cout<<"     ";
		else {
			if(board[i][j]>0 && board[i][j]<10)
			cout<<"  "<<board[i][j]<<"  ";
			if(board[i][j]>=10 && board[i][j]<100)
			cout<<"  "<<board[i][j]<<" ";
			if(board[i][j]>=100 && board[i][j]<1000)
			cout<<" "<<board[i][j]<<" ";
			if(board[i][j]>=1000 && board[i][j]<10000)
			cout<<" "<<board[i][j]<<"";
		}
	}
	cout<<"        |"<<endl;
	}
	cout<<setw(98)<<"------------------------------------------------------------------------------------------"<<endl;
}

void shiftLeft(int board[4][4]) {
	for(int i=0; i<4; i++){
		for(int j=0; j<3; j++){
			if(board[i][j] == 0  &&  board[i][j+1] == 0  && board[i][j+2] == 0){
				
				for (int k=j; k<3; k++)
					board[i][k] = board[i][k+1];
				
				board[i][3] = 0;
				for (int k=j; k<3; k++)
					board[i][k] = board[i][k+1];
				
				board[i][3] = 0;
				for (int k=j; k<3; k++)
					board[i][k] = board[i][k+1];
				
				board[i][3] = 0;
			}
				else if(board[i][j] == 0  && board[i][j+1] == 0){
					
					for(int k=j; k<3; k++)
						board[i][k] = board[i][k+1];
					
					board[i][3] = 0;
				for(int k=j; k<3; k++)
						board[i][k] = board[i][k+1];
					
					board[i][3] = 0;	}
				else if(board[i][j] == 0){
					
						for(int k=j; k<3; k++)
						board[i][k] = board[i][k+1];
				
					board[i][3] = 0;}
				}
            }
            // if two index have same numbers
            for(int i=0; i<4; i++){
		for(int j=0; j<4; j++){
			if(board[i][j] == board[i][j+1]){
				board[i][j] = board[i][j] + board[i][j+1];
				for (int k=j+1; k<4; k++)
					board[i][k] = board[i][k+1];

				board[i][3] = 0;
			}
		}
	}
	int num1, num2;
	randomIndex(board, num1, num2);
	board[num1][num2] = randomNumber();
}

void shiftRight(int board[4][4]){
	for(int i=0; i<4; i++){
		for(int j=3; j>0; j--){
			if(board[i][j] == 0  &&  board[i][j-1] == 0  && board[i][j-2] == 0){
				for (int k=j; k>0; k--)
					board[i][k] = board[i][k-1];
				
				board[i][0] = 0;
				for (int k=j; k>0; k--)
					board[i][k] = board[i][k-1];
				
				board[i][0] = 0;
				for (int k=j; k>0; k--)
					board[i][k] = board[i][k-1];
				
				board[i][0] = 0;
			}
				else if(board[i][j] == 0  && board[i][j-1] == 0){
					for(int k=j; k>0; k--)
						board[i][k] = board[i][k-1];
					
					board[i][0] = 0;
				    for(int k=j; k>0; k--)
						board[i][k] = board[i][k-1];
					
					board[i][0] = 0;	}
				else if(board[i][j] == 0){
						for(int k=j; k>0; k--)
						board[i][k] = board[i][k-1];
					
					board[i][0] = 0;}
				}
            }
            // if two index have same numbers
            for(int i=0; i<4; i++){
		for(int j=3; j>0; j--){
			if(board[i][j] == board[i][j-1]){
				board[i][j] = board[i][j] + board[i][j-1];
				for (int k=j-1; k>=0; k--)
					board[i][k] = board[i][k-1];
			
				board[i][0] = 0;  //LAST ELEMENT ZERO
			}
		}
	}
	int num1, num2;
	randomIndex(board, num1, num2);
	board[num1][num2] = randomNumber();
}

void shiftUp(int board[4][4]){
	for (int i=0; i<4; i++){
		for (int j=0; j<4; j++){
			if (board[j][i] == 0  &&  board[j+1][i] == 0  && board[j+2][i] == 0){
				for (int k=j; k<3; k++)
					board[k][i] = board[k+1][i];
				
				board[3][i] = 0;
				for (int k=j; k<3; k++)
					board[k][i] = board[k+1][i];
				
				board[3][i] = 0;
				for (int k=j; k<3; k++)
					board[k][i] = board[k+1][i];
				
				board[3][i] = 0;
			}
			else if (board[j][i] == 0  &&  board[j+1][i] == 0){
				for (int k=j; k<3; k++)
					board[k][i] = board[k+1][i];
				
				board[3][i] = 0;
				for (int k=j; k<3; k++)
					board[k][i] = board[k+1][i];
				
				board[3][i] = 0;
			}
			else if (board[j][i] == 0){
				for (int k=j; k<3; k++)
					board[k][i] = board[k+1][i];
				
				board[3][i] = 0;
			}
		}
	}
	//if two index have same numbers 
	for(int i=0; i<4; i++){
		for(int j=0; j<4; j++){
			if (board[j][i] == board[j+1][i]){
				board[j][i] = board[j][i] + board[j+1][i];
			
			for (int k=j+1; k<3; k++)
				board[k][i] = board[k+1][i];
			
			board[3][i] = 0;
		}
	}
}
	int num1, num2;
	randomIndex(board, num1, num2);
	board[num1][num2] = randomNumber();
}

void shiftDown(int board[4][4]){
	for (int i=0; i<4; i++){
		for (int j=3; j>0; j--){
			if (board[j][i] == 0  &&  board[j-1][i] == 0  && board[j-2][i] == 0){
				for (int k=j; k>0; k--)
					board[k][i] = board[k-1][i];
				
				board[0][i] = 0;
				for (int k=j; k>0; k--)
					board[k][i] = board[k-1][i];
				
				board[0][i] = 0;
				for (int k=j; k>0; k--)
					board[k][i] = board[k-1][i];
				
				board[0][i] = 0;
			}
			else if (board[j][i] == 0  &&  board[j-1][i] == 0){
				for (int k=j; k>0; k--)
					board[k][i] = board[k-1][i];
				
				board[0][i] = 0;
				for (int k=j; k>0; k--)
					board[k][i] = board[k-1][i];
				
				board[0][i] = 0;
			}
			else if (board[j][i] == 0){
				for (int k=j; k>0; k--)
					board[k][i] = board[k-1][i];
				
				board[0][i] = 0;
			}
		}
	}
	//if two index have same numbers 
	for(int i=0; i<4; i++){
		for(int j=3; j>0; j--){
			if (board[j][i] == board[j-1][i]){
				board[j][i] = board[j][i] + board[j-1][i];
	
			for (int k=j-1; k>0; k--)
				board[k][i] = board[k-1][i];
			
			board[0][i] = 0;
		}
	}
}
	int num1, num2;
	randomIndex(board, num1, num2);
	board[num1][num2] = randomNumber();
}

void input(int board[4][4]){
	char start='0';
	cout<<endl;
	bool check = true;
	while(1){
		if (check == true){
			cout<<setw(60)<<"ENTER A KEY : ";
			cin>>start;
		}
		if (start == 'q' || start == 'l' || start == 'r' || start == 'u' || start == 'd'){
			check = true;
			if(start == 'l'){
				shiftLeft(board);
				break;
			}
			else if(start == 'r'){
				shiftRight(board);
				break;
			}
			else if(start == 'u'){
				shiftUp(board);
				break;
			}
			else if(start == 'd'){
				shiftDown(board);
				break;
			}
			else if(start == 'q'){
				cout<<"QUITING. . . ."<<endl;
				exit(0);
			}
		}
		else {
			check = false;
			cout<<setw(60)<<"ENTER A VALID KEY : ";
			cin>>start;
		}
	}
}

void mainGame()
{
	char start;
	cout<<endl<<endl<<endl;
	cout<<setw(60)<<"WELCOME TO 1024 GAME "<<endl<<endl;
	cout<<setw(80)<<"ENTER ANY ALPHA AND PRESS ENTER TO START "<<endl<<endl;
	cout<<setw(53)<<"ENTER A KEY : ";
	cin>>start;
	system("cls");
	
		int board[4][4];
		int num1, num2;
		//initialize board
		for (int i=0; i<4; i++){
			for (int j=0; j<4; j++){
				board[i][j] = 0;
			}
		}
		cout<<endl;
		randomIndex(board, num1, num2);
		board[num1][num2] = randomNumber();
	    randomIndex(board, num1, num2);
		board[num1][num2] = randomNumber();
		
		while(1)
		{
			system("CLS");
			mainGrid(board);
			cout<<endl;
			input(board);
			
			if(board[0][0]>0 && board[0][1]>0 && board[0][2]>0 && board[0][3]>0 &&
			board[1][0]>0 && board[1][1]>0 && board[1][2]>0 && board[1][3]>0 &&
			board[2][0]>0 && board[2][1]>0 && board[2][2]>0 && board[2][3]>0 &&
			board[3][0]>0 && board[3][1]>0 && board[3][2]>0 && board[3][3]>0 )
			{
				cout<<endl<<setw(60)<<"GAME OVER "<<endl;
				break;
			}
			 bool flag = false;
				for(int i=0; i<4; i++){
				for(int j=0; j<4; j++){
					if(board[i][j] == 1024){
					flag = true;
				}
			}
			if (flag == true){
				break;
			}
		}
		if (flag == true){
			system("CLS");
			mainGrid(board);
			cout<<setw(50)<<"YOU WON THE GAME !! "<<endl;
			break;}
				
		}
	}		
int main()
{
	mainGame();
	return 0;
}
