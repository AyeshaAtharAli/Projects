# Vehicle Counter
Contador de veículos escrito em Python e OpenCV.
<br><br>
Você vai precisar:
- OpenCV
- Numpy
- Time
<br><br>
Confira a explicação do código no vídeo:<br>
<a href="https://youtu.be/25ERpsQcsrY">https://youtu.be/25ERpsQcsrY</a>
